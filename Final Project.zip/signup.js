var text = prompt("Welcome, please enter your age: ");
var age;

if (age < 18)
{
	msg = "Welcome guest!!!";
}
	else 
	{
		msg = "Proceed to Sign Up!!!";
	}
	

