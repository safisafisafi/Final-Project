/*
function myFunction() 
{
	document.getElementById("click").innerHTML = "home.html";
}

window.addEventListener("load", addListeners); 

function Redirect() 
{
    window.location='home';
}
*/
 function pageClick()
 {
	 window.location ="home.html";
 }