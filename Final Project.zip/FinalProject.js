//Ticket//

var numberOfTicket = (Math.random() * 100);

function ticket() 
{
    var numberOfTicket = Math.floor((Math.random() * 100) + 1);          
	return numberOfTicket;
}
function changeText() 
{
	output=document.getElementById("raffle");
	outputName=output.elements["username"].value;
    output=document.getElementById("raffle");
	outputNumber=output.elements["ticket"];
	document.getElementById("raffle1").innerHTML= "<h5> Dear "+ outputName + ", your ticket number is: " + outputNumber + "</h5>";
}
function update(e)
{
	e.preventDefault();
	//var formEl = document.getElementsByTagName("form")[0];
	//formEl.style.display = "none";
	console.log("Updated!");
}
	var myButton = document.getElementById("update");
	if (myButton.addEventListener)
	{
		myButton.addEventListener("click", update, false);
	}
	else
	{
		myButton.attachEvent("onclick", update);
	}
	
//Comunity//

function changeText1() 
{
	output=document.getElementById("form");
	outputText=output.elements["beautytip"].value;
	document.getElementById("form").innerHTML= "Your post entry is: " + outputText;
}

//Sign Up//

var age;

if (age < 18)
{
	msg = "Welcome guest!!!";
}
	else 
	{
		msg = "Proceed to Sign Up!!!";
	}
	
//Blog//

function changeText2() 
{
	output=document.getElementById("form");
	outputText=output.elements["blog"].value;
	document.getElementById("form").innerHTML= "Your blog entry is: " + outputText;
}

//E-mail//

function changeText3() 
{
	output=document.getElementById("form");
	outputText=output.elements["mail"].value;
	document.getElementById("form").innerHTML= "Your e-mail is: " + outputText;
}

//report a lost//

function changeText4() 
{
	output=document.getElementById("form");
	outputText=output.elements["lost"].value;
	document.getElementById("form").innerHTML= "Your lost report is: " + outputText;
}

//report a problem//

function changeText5() 
{
	output=document.getElementById("form");
	outputText=output.elements["problem"].value;
	document.getElementById("form").innerHTML= "Your problem report is: " + outputText;
}

//Update//

function changeText6() 
{
	output=document.getElementById("form");
	outputText=output.elements["update"].value;
	document.getElementById("form").innerHTML= "Your update request is: " + outputText;
}


