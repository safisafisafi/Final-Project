 var myDate = new Date();
 var hours = myDate.getHours();


if(hours < 12)
{
     document.write("<marquee> Good Morning Gorgeous! </marquee>");
	 document.write("<br>");
	 document.write("<marquee> Welcome to Nefertiti World! </marquee>");   
}
	else if (hours >= 12 && hours <= 15)
	{
		document.write("<marquee> Good Afternoon Gorgeous! </marquee>");
		document.write("<br>");
		document.write("<marquee> Welcome to Nefertiti World! </marquee>");   
	}
	else if (hours >= 15 && hours <=17)
	{
		document.write("<marquee> Good Evening Gorgeous! </marquee>");
		document.write("<br>");
		document.write("<marquee> Welcome to Nefertiti World! </marquee>");
	}
	else if (hours >= 17 && hours <= 24)
	{
		document.write("<marquee> Good Night Gorgeous! </marquee>");
		document.write("<br>");
		document.write("<marquee> Welcome to Nefertiti World! </marquee>");
	}
